//
//  GameViewController.h
//  Flappy Bird
//
//  Created by Whisper on 2018/1/25.
//  Copyright © 2018年 pactera. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <SpriteKit/SpriteKit.h>
#import <GameplayKit/GameplayKit.h>

@interface GameViewController : UIViewController

@end
